export interface Hero
{
  id: number,
  nome: string;
}
